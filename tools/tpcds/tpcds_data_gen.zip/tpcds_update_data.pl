#!/usr/bin/perl -w

###############################################################################
# This script unzips the TPCDS installer located in the src directory 
# to the specified directory, compiles the code using the makefile 
# also located in the src directory and generates the data.
#
# Usage: perl tpcds_gen_data.pl data.properties
#
# Parameters Used: tpcds_home, scaling_factor, num_file_splits
#
# Author: Andy He
# Date: Jun 09, 2013
#
##############################################################################

use lib "./src";
use GetOptions qw(get_options println);

# Error checking
if ($#ARGV != 0)
{
   print qq(Usage: perl $0 data.properties\n);
   exit(-1);
}

# Get input parameters
%opt = get_options($ARGV[0]);
$TPCDS_HOME        = $opt{'tpcds_home'};
$SCALING_FACTOR   = $opt{'scaling_factor'};
$UPDATE_PARTITION = $opt{'update_partition'};
$NUM_FILE_SPLITS  = $opt{'num_file_splits'};
$FIRST_FILE_SPLIT = $opt{'first_file_split'};
$LAST_FILE_SPLIT  = $opt{'last_file_split'};

# Error checking
if ($FIRST_FILE_SPLIT < 1)
{
   println qq(Error: first_file_split = $FIRST_FILE_SPLIT: must be >= 1);
}
if ($LAST_FILE_SPLIT > $NUM_FILE_SPLITS)
{
   println qq(Error: last_file_split = $LAST_FILE_SPLIT:).
           qq( must be <= $NUM_FILE_SPLITS);
}

# Output input parameters
!system qq(date) or die $!;
println "Input Parameters:";
println "TPCDS home dir: $TPCDS_HOME";
println "Scaling factor: $SCALING_FACTOR";
println "Number of file splits: $NUM_FILE_SPLITS";
println "Generate file splits: $FIRST_FILE_SPLIT TO $LAST_FILE_SPLIT";
println "";

# Execute make
println "Executing make";
chdir $TPCDS_HOME or die $!;
!system qq(make) or die $!;
println "Make completed";
println "";

# Generate the data
$current = `date`; $current =~ s/\s+$//;
println "Starting TPCDS data generation at $current";
println "This might take some time depending on the scale factor...";

for ($split = $FIRST_FILE_SPLIT; $split <= $LAST_FILE_SPLIT; $split++)
{
   println "";
   $options = "-SCALE $SCALING_FACTOR -UPDATE $UPDATE_PARTITION -PARALLEL $NUM_FILE_SPLITS -CHILD $split -FORCE Y";
   !system qq(./dsdgen $options) or die $!;
}

!system qq(chmod 644 *.dat) or die $!;
println "Data generation complete";
println "";

# Done
$current = `date`; $current =~ s/\s+$//;
println qq{Done at $current};

$time = time - $^T;
println "Time taken (sec):\t$time";

